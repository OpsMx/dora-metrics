#!/bin/bash

    # This function searches for Kubernetes manifest files in the specified directory
    # that match the given kind. It prints the names of the files containing the kind.
    # Arguments:
    #   dir: The directory to search for manifest files.
    #   kind: The Kubernetes resource kind to search for in the manifest files.

get_k8s_manifests_by_kind() {
    local dir="$1"
    local kind="$2"
    #grep -lE "^kind:\s*$kind" "$dir"/*/*/*.yaml  2>/dev/null
    find "$dir" -type f -name "*.yaml" -exec grep -lE "^kind:\s*$kind" {} + 2>/dev/null
}

    # This function checks if the given image is a valid nginx image.
    # It matches the image against the pattern "nginx" followed optionally by a colon and version numbers.
    # Arguments:
    #   image: The image string to validate.
    # Returns:
    #   True (0) if the image matches the nginx pattern, otherwise False (1).

validate_image() {
    local image="$1"
    [[ "$image" =~ ^nginx(:[0-9]+(\.[0-9]+)*)?$ ]]
}

# Define the list of Kubernetes Kinds that have an image field
kinds=("Deployment" "StatefulSet" "DaemonSet" "Job" "CronJob" "Pod")
declare -a manifest_files
declare -A images_map

#get config.jsons
echo finding config.json files in current repo
find . -name config.json > config_jsons.txt
#cat config_jsons.txt
echo
echo loop over each config.json
echo
#loop over each config.json
while read config_json; do
echo working with $config_json
repoURL=$(cat $config_json | jq -r '.repoURL')
#echo repoURL: $repoURL
chartVersion=$(cat $config_json | jq -r '.chartVersion')
#echo chartVersion: $chartVersion
chart=$(cat $config_json | jq -r '.chart')
#echo chart: $chart
valuesPath=$(cat $config_json | jq -r '.valuesPath')
#echo valuesPath: $valuesPath
valuesOverlayPath=$(cat $config_json | jq -r '.valuesOverlayPath')
#echo valuesOverlayPath: $valuesOverlayPath
name=$(cat $config_json | jq -r '.name')
#echo repoURL: $repoURL, chartVersion: $chartVersion, chart: $chart, valuesPath: $valuesPath, valuesOverlayPath: $valuesOverlayPath, name: $name

base_dir=$(dirname $config_json)
#echo base_dir: $base_dir
mkdir -p $base_dir/$name
echo running helm template and putting manifests in $base_dir/$name
helm template --repo $repoURL  $chart --version $chartVersion --values $valuesPath --values $valuesOverlayPath --output-dir $base_dir/$name 2>/dev/null

# Loop through each kind and collect matching files
for kind in "${kinds[@]}"; do
    #echo getting $kind from folder $base_dir/$name
    files=$(get_k8s_manifests_by_kind $base_dir/$name "$kind")
    if [[ -n "$files" ]]; then
       manifest_files+=($files)
    fi
done
echo
done < config_jsons.txt
echo these are the manifest files with images
# Print all collected manifest files
printf "%s\n" "${manifest_files[@]}"

# Extract container images from each file

for file in "${manifest_files[@]}"; do
    images=$(yq eval '.spec.template.spec.containers[].image, .spec.template.spec.initContainers[].image' "$file" 2>/dev/null)
    
    if [[ -n "$images" ]]; then
        images_map["$file"]="$images"
    fi
done

echo
echo the following images are invalid
for file in "${!images_map[@]}"; do
    while read -r image; do
        if ! validate_image "$image"; then
            echo "File: $file"
            echo "  - $image"
        fi
    done <<< "${images_map[$file]}"
done
